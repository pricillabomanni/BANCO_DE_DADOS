package br.com.bibliotecapricilla.bibliotecapricilla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecapricillaApplicationTests {

	@Test
	void contextLoads() {
	}

}
