package br.com.bibliotecapricilla.bibliotecapricilla;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliotecapricillaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliotecapricillaApplication.class, args);
	}

}
